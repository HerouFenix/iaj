﻿using UnityEngine;

namespace Assets.Scripts.IAJ.Unity.Movement.DynamicMovement
{
    public class DynamicWander : DynamicSeek
    {
        public DynamicWander()
        {
            this.Target = new KinematicData();
        }
        public override string Name
        {
            get { return "Wander"; }
        }
        public float TurnAngle { get; set; }
        public float WanderOffset { get; set; }
        public float WanderRadius { get; set; }
        public float WanderRate { get; set; }
        protected float WanderOrientation { get; set; }
        public Vector3 CircleCenter { get; private set; }
        public GameObject DebugTarget { get; set; }

        public override MovementOutput GetMovement()
        {
            // I wander (get it) if there's something missing here...

            if (this.DebugTarget != null)
            {
                this.DebugTarget.transform.position = this.Target.position;
            }

            return null;
        }
    }
}
